// apx_io.hpp
#pragma once
#include <vector>
#include <iosfwd>
#include "types.hpp"
#include "apx_format.hpp"
#include <Geode/binding/PlayerObject.hpp>

bool writeAPXPracticePath(std::ostream& os, const PracticePath& path);
bool readAPXPracticePath(std::istream& in, uint32_t chunkSize, PracticePath& path);
bool writeAPXAttemptCompact(std::ostream& out, Attempt const& attempt);
bool readAPXAttemptCompact(std::istream& in, uint32_t chunkSize, Attempt& attempt);

