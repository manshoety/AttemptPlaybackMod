// hook_play_layer.cpp
#include <Geode/DefaultInclude.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/binding/PlayLayer.hpp>
#include "../core/ghost_manager.hpp"
#include "../core/globals.hpp"

using namespace geode::prelude;

class $modify(PLHook, PlayLayer) {
    struct Fields {
        cocos2d::CCLabelBMFont* m_ghostTextLabel = nullptr;
    };
    void createGhostTextLabel_() {
        if (m_fields->m_ghostTextLabel) return;

        auto* label = cocos2d::CCLabelBMFont::create("", "bigFont.fnt");
        if (!label) return;

        label->setAnchorPoint({ 0.f, 1.f });
        label->setPosition({ 20.f, 280.f });
        label->setScale(0.45f);
        label->setOpacity(180);
        label->setVisible(false);
        label->setColor({ 255, 255, 255 });

        this->addChild(label, 9999);

        m_fields->m_ghostTextLabel = label;
        Ghosts::I().setPlayLayerGhostTextLabel(label);
    }
    $override bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) return false;
        auto& G = Ghosts::I();
        G.clearPlayLayerGhostTextLabel();
        G.updateModEnabled();
        if (G.isModEnabled()) {
            // log::info("Attaching to level");
            int lvlId = level ? level->m_levelID : 0;
            G.prepareLevelPersistence(lvlId, this);
            G.m_levelIDOnAttach = lvlId;
            G.attach(this);
            createGhostTextLabel_();
            if (G.isRecording()) {
                G.renumberCurrentAttemptIfFresh();
            }

            G.stopReplay();
        }
        
        return true;
    }
    $override void resetLevel() {
        //log::info("[PlayLayer] resetLevel");
        if (Ghosts::I().isAttachedPlayLayer(this)) Ghosts::I().setResetting(true);
        
        PlayLayer::resetLevel();
        if (Ghosts::I().isAttachedPlayLayer(this)) {
            Ghosts::I().onReset();
            Ghosts::I().setResetting(false);
        }
    }
    // Someone crashed here? Who knows why.
    //$override void updateTimeLabel(int seconds, int centiseconds, bool decimals) {
    //    log::info("[PlayLayer] updateTimeLabel seconds: {}, centiseconds: {}, decimals: {}", seconds, centiseconds, decimals);
    //    PlayLayer::updateTimeLabel(seconds, centiseconds, decimals);
    //}
    //$override void onExit() { Pausing?
    //    //log::info("[PlayLayer] onExit");
    //    PlayLayer::onExit();
    //}
    $override void onQuit() {
        auto& G = Ghosts::I();

        if (G.isAttachedPlayLayer(this)) {
            G.clearPlayLayerGhostTextLabel();
            G.saveNewAttemptsForCurrentLevel();
            G.onQuit();
        }

        PlayLayer::onQuit();
    }
    static void onModify(auto& self) {
        if (!self.setHookPriorityPre("PlayLayer::levelComplete", Priority::First)) {
            log::warn("Failed to set first levelComplete pre-hook priority");
        }
        if (Loader::get()->isModInstalled(kDeathTrackerModID)) {
            if (!self.setHookPriorityBeforePre("PlayLayer::levelComplete", kDeathTrackerModID)) {
                log::warn("Failed to place levelComplete before Death Tracker Mod");
            }
        }
        if (Loader::get()->isModInstalled(kMoreThan100ModID)) {
            if (!self.setHookPriorityBeforePre("PlayLayer::levelComplete", kMoreThan100ModID)) {
                log::warn("Failed to place levelComplete before More Than 100 Mod");
            }
        }
    }
    $override void levelComplete() {
        // log::info("[PlayLayer] levelComplete");
        if (Ghosts::I().isAttachedPlayLayer(this)) {
            if (Ghosts::I().safeMode_enabled) {
                PlayLayer::showCompleteText();
                return;
            }
            Ghosts::I().onComplete();
        }
        PlayLayer::levelComplete();
    } 
    // Idk how to check consistantly if a mod is using noclip
    // I want to add a toggle for "don't record noclip runs"
    $override void destroyPlayer(PlayerObject* p0, GameObject* p1) {
        auto& G = Ghosts::I();
        if (!G.isAttachedPlayLayer(this)) {
            PlayLayer::destroyPlayer(p0, p1);
            return;
        }
        if (G.noclip_enabled) return;
        PlayLayer::destroyPlayer(p0, p1);
        if (this->m_playerDied) {
            G.onDeath();
        }
    }
    $override void showNewBest(bool newReward, int orbs, int diamonds, bool demonKey, bool noRetry, bool noTitle) {
        // log::info("[PlayLayer] showNewBest");
        if (!Ghosts::I().isAttachedPlayLayer(this) || !Ghosts::I().safeMode_enabled) {
            PlayLayer::showNewBest(newReward, orbs, diamonds, demonKey, noRetry, noTitle);
        }
    }
    $override void updateAttempts() {
        if (Ghosts::I().isAttachedPlayLayer(this) && Ghosts::I().isUpdateAttemptCountBlocked()) return;
        PlayLayer::updateAttempts();
    }

    $override void playEndAnimationToPos(CCPoint position) {
        if (Ghosts::I().isAttachedPlayLayer(this)) Ghosts::I().hasReachedEndOfLevel();
        PlayLayer::playEndAnimationToPos(position);
    }
    //$override void activateEndTrigger(int targetID, bool reverse, bool lockPlayerY) { // can't hook
    //    log::info("[PlayLayer] activateEndTrigger targetID {}, reverse {}, lockPlayerY {}", targetID, reverse, lockPlayerY);
    //    PlayLayer::activateEndTrigger(targetID, reverse, lockPlayerY);
    //}
    //$override void pauseGame(bool p0) {
    //    //log::info("[PlayLayer] pauseGame {}", p0);
    //    PlayLayer::pauseGame(p0);
    //}
    //$override void storeCheckpoint(CheckpointObject* p0) {
    //    //log::info("[PlayLayer] storeCheckpoint()");
    //    PlayLayer::storeCheckpoint(p0);
    //}
    //$override void createCheckpoint() {
    //    //log::info("[PlayLayer] createCheckpoint()");
    //    PlayLayer::createCheckpoint();
    //}
    //$override void removeCheckpoint(bool p0) {
        //log::info("[PlayLayer] removeCheckpoint({})", p0);
    //    PlayLayer::removeCheckpoint(p0);
    //    if (Ghosts::I().isAttachedPlayLayer(this)) {
    //        Ghosts::I().onPracticeUndoCheckpoint();
    //    }
    //}
    $override void togglePracticeMode(bool on) {
        // log::info("[PlayLayer] togglePracticeMode({})", on);
        if (Ghosts::I().isAttachedPlayLayer(this)) Ghosts::I().onPracticeToggle(on);
        PlayLayer::togglePracticeMode(on);
    }
    //$override void commitJumps() {
    //    PlayLayer::commitJumps();
    //}
    //$override void update(float dt) {
    //    PlayLayer::update(dt);
    //}
    
    //$override void postUpdate(float dt) {
    //    PlayLayer::postUpdate(dt);
        
    //}
    //$override float getCurrentPercent() {
    //    return PlayLayer::getCurrentPercent();
    //}
};


class $modify(DestroyPlayerEarliest, PlayLayer) {
    static void onModify(auto& self) {
        if (!self.setHookPriorityPre("PlayLayer::destroyPlayer", Priority::First)) {
            log::warn("Failed to set earliest destroyPlayer priority");
        }
    }

    void destroyPlayer(PlayerObject* p0, GameObject* p1) {
        if (Ghosts::I().isAttachedPlayLayer(this)) {
            // I'm dumb and didn't realize this was a thing
            if (p1 && (p1 == m_anticheatSpike)) {
                PlayLayer::destroyPlayer(p0, p1);
                return;
            }
            // WHY DID SOMEONE MAKE A SAWBLADE THE PLAYER SPAWN OBJECT AND HOW DOES THAT NOT KILL THE PLAYER???
            // To fix that I will just not check until 45 units (1.5 blocks) from the start of the level
            if ((p0 && p0->m_position.x < 45)) {
                PlayLayer::destroyPlayer(p0, p1);
                return;
            }
            // Make sure it's not that wacky invisible object Rob puts at the start of every level
            if (p1) {
                if (!(p1->m_positionX == 0 && p1->m_positionY == 105)) Ghosts::I().beginPlayerDestroyedCheck();
            }
            else Ghosts::I().beginPlayerDestroyedCheck();
        }
        
        PlayLayer::destroyPlayer(p0, p1);
    }
};

class $modify(DestroyPlayerLatest, PlayLayer) {
    static void onModify(auto& self) {
        if (!self.setHookPriorityPost("PlayLayer::destroyPlayer", Priority::Last)) {
            log::warn("Failed to set latest destroyPlayer priority");
        }
        if (!self.setHookPriorityPost("PlayLayer::resetLevel", Priority::Last)) {
            log::warn("Failed to set latest resetLevel priority");
        }
    }

    void destroyPlayer(PlayerObject* p0, GameObject* p1) {
        PlayLayer::destroyPlayer(p0, p1);

        if (Ghosts::I().isAttachedPlayLayer(this)) {
            Ghosts::I().endPlayerDestroyedCheck(this->m_playerDied);
            // log::info("End player destroyed");
        }
    }
    void resetLevel() {
        PlayLayer::resetLevel();
        if (Ghosts::I().isAttachedPlayLayer(this)) Ghosts::I().resetNoclipDetectedFlag();
        // log::info("Reset level");
    }
};


