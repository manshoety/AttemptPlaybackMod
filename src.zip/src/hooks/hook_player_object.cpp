// hook_player_object.cpp
#include <Geode/DefaultInclude.hpp>
#include <Geode/modify/PlayerObject.hpp>
#include <Geode/binding/PlayerObject.hpp>
#include <Geode/binding/PlayLayer.hpp>
#include "../core/ghost_manager.hpp"
#include "../core/globals.hpp"
#include <Geode/loader/Log.hpp>
#include <chrono>

using namespace geode::prelude;

class $modify(MyPlayerObject, PlayerObject) {
    //bool init(int player, int ship, GJBaseGameLayer* gameLayer, CCLayer* layer, bool playLayer) {
    //    if (!PlayerObject::init(player, ship, gameLayer, layer, playLayer)) return false;
        // log::info("PlayerObject::init");
    //    return true;
    //}

    PlayLayer* attachedPlayLayerForThis_() {
        auto& G = Ghosts::I();

        auto* pl = G.getPlayLayer();
        if (!pl || !G.shouldHandlePlayLayer(pl)) return nullptr;

        auto* p1 = pl->m_player1;
        auto* p2 = pl->m_player2;

        if (this != p1 && this != p2) {
            return nullptr;
        }

        return pl;
    }

    bool pushButton(PlayerButton btn) {
        if (auto* pl = attachedPlayLayerForThis_()) {
            if (this == pl->m_player1) {
                // log::info("button: {}, holding: true", int(btn));
                if (btn==PlayerButton::Jump) Ghosts::I().setP1Hold(true);
                else if (btn==PlayerButton::Left) Ghosts::I().setP1LHold(true);
                else if (btn==PlayerButton::Right) Ghosts::I().setP1RHold(true);
                // log::info("[PlayerObject] pushButton({})", int(btn));
            }
            else if (this == pl->m_player2) {
                if (btn==PlayerButton::Jump) Ghosts::I().setP2Hold(true);
                else if (btn==PlayerButton::Left) Ghosts::I().setP2LHold(true);
                else if (btn==PlayerButton::Right) Ghosts::I().setP2RHold(true);
            }
        }
        return PlayerObject::pushButton(btn);
    }
    bool releaseButton(PlayerButton btn) {
        if (auto* pl = attachedPlayLayerForThis_()) {
            if (this == pl->m_player1) {
                // log::info("button: {}, holding: false", int(btn));
                if (btn==PlayerButton::Jump) Ghosts::I().setP1Hold(false);
                else if (btn==PlayerButton::Left) Ghosts::I().setP1LHold(false);
                else if (btn==PlayerButton::Right) Ghosts::I().setP1RHold(false);
                // log::info("[PlayerObject] releaseButton({})", int(btn));
            }
            else if (this == pl->m_player2) {
                
                if (btn==PlayerButton::Jump) Ghosts::I().setP2Hold(false);
                else if (btn==PlayerButton::Left) Ghosts::I().setP2LHold(false);
                else if (btn==PlayerButton::Right) Ghosts::I().setP2RHold(false);
            }
        }
        return PlayerObject::releaseButton(btn);
    } 
    //void playerDestroyed(bool noEffects) {
    //    log::info("playerDestroyed");
    //    PlayerObject::playerDestroyed(noEffects);
    //}
    // Update order
    // SET previous position
    // Player object update
    // SET MY position
    // SET current position
    // Player object update done
    // SET current position (If I manually override this, I can avoid wacky GD placement issues, and have follow player objects work)
    // And I need to set that to what GD wants it to be, not what I want it to be
    // Still have no clue why GD sometimes sets this value to actual garbage when I mess with the real player position (super wrong y pos like 405)
    void setPosition(CCPoint const& position) {
        auto& ghosts = Ghosts::I();

        auto* pl = attachedPlayLayerForThis_();
        const bool isP1 = pl && this == pl->m_player1;
        const bool isP2 = pl && this == pl->m_player2;

        // log::info("Setting player pos: isP1: {}", isP1);
        //log::info("Next lets check if the position is valid");
        //log::info("x: {}, y: {}", position.x, position.y);
        //log::info("Position is valid");

        if (pl && ghosts.shouldHandlePlayLayer(pl) && ghosts.isBotActive()) {
            if (ghosts.isResetting()) {
                PlayerObject::setPosition(position);
                return;
            }

            if (ghosts.isdisablePlayerMove()) {
                //log::info("Disable update");
                if (isP1) {
                    PlayerObject::setPosition(ghosts.forceSetPosP1);
                    return;
                }
                if (isP2) {
                    if (ghosts.forceSetPosP2.x == 0.f) PlayerObject::setPosition(position);
                    else PlayerObject::setPosition(ghosts.forceSetPosP2);
                    return;
                }
            } else {
                //log::info("Not disabled update");
                if (isP1) ghosts.forceSetPosP1 = position;
                else if (isP2 && position.x) ghosts.forceSetPosP2 = position;
            }
        }

        PlayerObject::setPosition(position);
    }

    void playSpawnEffect() {
        if (!attachedPlayLayerForThis_()) {
            PlayerObject::playSpawnEffect();
        }
    }

    void update(float p0) { //  is p0 the frac of real GJ update?
        // start time here
        auto& G = Ghosts::I();
        if (G.isModEnabled()) {
            if (auto* pl = attachedPlayLayerForThis_()) {
                if (G.shouldHandlePlayLayer(pl)) {
                    // log::info("p1: {}, p2: {}", this == pl->m_player1, this == pl->m_player2);
                    if (this == pl->m_player1) {
                        //log::info("update");
                        G.setdisablePlayerMove(false);

                        G.preUpdate();
                        
                        G.applySegmentBasedReplay_(/*isPlayer1*/true);
                        
                        G.beginPostUpdateTick_();

                        G.recordUpdate(/*isPlayer1*/true);

                        G.endPostUpdateTick_();

                        // if (!Ghosts::I().isBotActive()) 
                        PlayerObject::update(p0);

                        //log::info("update done");
                        //Ghosts::I().updateClickState(/*isPlayer1*/true);

                        G.setdisablePlayerMove(true);

                        return;
                    }
                    else if (this == pl->m_player2) {
                        G.setdisablePlayerMove(false);

                        G.preUpdateP2();
                        
                        G.applySegmentBasedReplay_(/*isPlayer1*/false);
                        
                        G.beginPostUpdateTick_();

                        
                        G.recordUpdate(/*isPlayer1*/false);
                        
                        G.endPostUpdateTick_();

                        
                        // if (!Ghosts::I().isBotActive())
                        PlayerObject::update(p0);

                        //Ghosts::I().updateClickState(/*isPlayer1*/false);
                        G.setdisablePlayerMove(true);

                        return;
                    }
                    //log::info("[PlayerObject] update {}", p0);
                }
            }
        }
        // end time here
        PlayerObject::update(p0);
    }

    void releaseAllButtons() {
        auto* pl = attachedPlayLayerForThis_();
        auto& G = Ghosts::I();

        if (pl) {
            G.setP1Hold(false);
            G.setP1LHold(false);
            G.setP1RHold(false);
            G.setP2Hold(false);
            G.setP2LHold(false);
            G.setP2RHold(false);
        }

        PlayerObject::releaseAllButtons();
    }

    void placeStreakPoint() {
        auto& G = Ghosts::I();

        if (G.shouldOwnWaveTrailDuringPlayback()) {
            auto* pl = attachedPlayLayerForThis_();

            if (pl && G.shouldHandlePlayLayer(pl)) {
                const bool isRealP1 = pl->m_player1 == this;
                const bool isRealP2 = pl->m_player2 == this;

                if ((isRealP1 || isRealP2) && this->m_isDart) return;
            }
        }

        PlayerObject::placeStreakPoint();
    }

    // Wave Trail Drag Fix mod forces me to put the wave point update in here (after the mod runs it's fix)
    void updateRotation(float dt) {
        PlayerObject::updateRotation(dt);
        auto& G = Ghosts::I();
        if (G.isModEnabled()) {
            if (auto* pl = attachedPlayLayerForThis_()) {
                if (G.shouldHandlePlayLayer(pl)) {
                    if (this == pl->m_player1) {
                        G.recordUpdate(/*isPlayer1*/true, true);
                        return;
                    }
                    else if (this == pl->m_player2) {
                        G.recordUpdate(/*isPlayer1*/false, true);
                        return;
                    }
                }
            }
        }
    }

    void setVisible(bool visible) {

        auto& G = Ghosts::I();
        if (G.isModEnabled() && G.isBotActive() && this->isVisible() != visible) {
            if (this->m_waveTrail) this->m_waveTrail->reset();
        }
        
        PlayerObject::setVisible(visible);
    }

    

    //void flipGravity(bool p0, bool p1) {
        // log::info("[PlayerObject] flipGravity({}, {})", p0, p1);
    //    PlayerObject::flipGravity(p0, p1);
    //}

    //void toggleFlyMode(bool p0, bool p1) {
        //log::info("[PlayerObject] toggleFlyMode({}, {})", p0, p1);
    //    PlayerObject::toggleFlyMode(p0, p1);
    //}

    //void toggleDartMode(bool p0, bool p1) {
        //log::info("[PlayerObject] toggleDartMode({}, {})", p0, p1);
    //    PlayerObject::toggleDartMode(p0, p1);
    //}

    //void setColor(ccColor3B const& color) {
        //log::info("[PlayerObject] color set, was me: {}", Ghosts::I().testerBool);
    //    PlayerObject::setColor(color);
    //}
};
